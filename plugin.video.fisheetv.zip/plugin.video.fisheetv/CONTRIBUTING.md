# How to contribute

Thanks you for contributing to FisheeTV for Kodi!
